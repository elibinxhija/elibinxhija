public class ThrowDice
{public static void main(String[] args)
 {new DieController().rollDice();
 }
}